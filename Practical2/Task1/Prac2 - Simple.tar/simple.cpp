//Mohamed Ameen Omar - 16055323 - Task1 2016.
//Header Files.
#include <iostream>
#include <string>

using namespace std;

int main()
{
	//Variable Declaration.
	string dash = "------------------------------------------------------------------------------";
	
    cout << dash << endl;
    cout << "This is COS132." << endl;
    cout << "My student number is u16055323." << endl;
    cout << dash << endl;
	
    return 0;
	
}


